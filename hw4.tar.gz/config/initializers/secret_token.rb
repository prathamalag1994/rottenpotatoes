# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rottenpotatoes::Application.config.secret_token = '9785fef10ef262f059dc3b5271f16173e99b606ee8f6a4ca71656f3c65a7700b3752bde8e8d59f7b2a358c04082804ccb3dc210f17a58eddbc3bbfbd3a684a66'
